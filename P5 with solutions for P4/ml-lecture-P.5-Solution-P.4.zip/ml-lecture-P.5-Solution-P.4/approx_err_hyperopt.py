import numpy as np
from hyperopt import hp, fmin, tpe
import math
from approximation_error import perform_approx
from approximation_error import FUNCTIONS, INTERVAL_LENGTHS, N_EPOCHS, N_TRAIN_DATAPOINTS
CURRENT_FUNCTION = None
CURRENT_BEST_ERR = np.inf

def objective(args):
    global CURRENT_BEST_ERR
    print(f"Objective: {args}")
    lr = np.round(args[0], decimals=4)
    n_hidden = int(args[1])
    sampling = args[2]
    optimizer = args[3]
    # batch_fraction = args[4]
    x_start = CURRENT_INTERVAL[0]
    x_end = CURRENT_INTERVAL[1]
    err = perform_approx(CURRENT_FUNCTION, n_hidden, x_start, x_end, lr,  N_EPOCHS, N_TRAIN_DATAPOINTS, batch_size=0, sampling=sampling, optimizer=optimizer, best_err=CURRENT_BEST_ERR)
    if err < CURRENT_BEST_ERR:
        CURRENT_BEST_ERR = err
    return err

if __name__ == '__main__':

    space = [
        hp.loguniform('lr', math.log(0.00001), math.log(0.1)),
        # hp.loguniform('n_hidden', math.log(1), math.log(10000)),
        hp.choice('n_hidden', [255]),
        hp.choice('sampling', ['homogeneous', 'random']),
        # hp.choice('sampling', ['homogeneous']),
        hp.choice('optimizer', ['sgd'])
        # hp.choice('optimizer', ['sgd'])
        ]
    all_functs = [FUNCTIONS[0]]
    all_intervals = [INTERVAL_LENGTHS[0]]
    for interval in all_intervals:
        x_start = 0 - interval / 2
        x_end = x_start + interval
        for func in all_functs:
            CURRENT_FUNCTION = func
            CURRENT_INTERVAL = (x_start, x_end)
            CURRENT_BEST_ERR = np.inf
            print(f"Optimizing for function {CURRENT_FUNCTION}")
            best = fmin(objective, space, algo=tpe.suggest, max_evals=100)
            print(f"Done. Best: {best}")
    print("Done with hyperopt")

