import math
import sys
import os
import time

from helper_functions import get_radius, gen_lin_sep_dataset, inner_prod
import numpy as np
import copy
import matplotlib.pyplot as plt
from tqdm import tqdm
from approx_err_util import BetterPytorchContiNN, EvenBetterPytorchContiNN
import torch.optim as optim
from plot_functions import plot_3d_surface_hidden_interval_approx

def sigmoid(x):
    z = 1 / (1 + np.exp(-x))
    return z


#####################
# Testing functions #
#####################

def function_1(x):
    y = np.exp(np.divide(-np.power(x,2),2))
    return np.array([y])


def function_2(x):
    y = math.sin(x)
    return np.array([y])


def function_3(x):
    y = math.cos(x)
    return np.array([y])


def function_4(x):
    y = sigmoid(x) + math.sin(x)
    return np.array([y])


def function_5(x):
    y = math.pow(x / 6, 2) - math.pow(x / 8, 4)
    return np.array([y])


def function_6(x):
    y = math.sin(x) * math.sqrt(abs(x))
    return np.array([y])


def perform_approx(func, n_hidden, x_start, x_end, lr, n_epochs, n_datapoints, sampling='homogeneous', optimizer='sgd', best_err=None, batch_size=0):
    approx = BetterPytorchContiNN(1, n_hidden, lr=lr, opti_str=optimizer, sampling=sampling, batch_size=batch_size)
    print(f"using approximator  {approx.__name__}")
    fname = f'{str(func.__name__)}_{str(x_start)}-{str(x_start)}_{str(approx.__name__)}.png'
    err = approx.fit(func, n_epochs, x_start, x_end, n_datapoints, figure_path=F_PATH, figure_filename=fname, best_err=best_err)
    return err


####################
# Global variables #
####################

FUNCTIONS = [function_1, function_2, function_3, function_4, function_5, function_6]
INTERVAL_LENGTHS = [2, 4, 8, 16]
N_HIDDEN_UNITS = [5, 25, 50, 255, 400, 800, 1600]
N_TRAIN_DATAPOINTS = 100
N_EPOCHS = 2000
N_EPOCHS = 20000
LEARNING_RATE = 0.04
F_PATH = 'approx_err_data'

if __name__ == '__main__':

    os.makedirs(F_PATH, exist_ok=True)

    ##############################
    # P5.1: Approximation of f_3 #
    ##############################

    # <START Your code here>

    # <END Your code here>

    #####################################################################################
    # P5.2: Approximation accuracy over different functions, intervals and hidden units #
    #####################################################################################
    for func in FUNCTIONS:
        print(f"approximating function {func.__name__}")
        data = {interval_len: {n_hidden: np.nan for n_hidden in N_HIDDEN_UNITS} for interval_len in INTERVAL_LENGTHS}
        # <START Your code here>

        # <END Your code here>
        # Plot with different angles
        for z_ang_hori in [0, 30, 90]:
            for z_ang_vert in [0, 45]:
                plot_3d_surface_hidden_interval_approx(data,
                                                       filename=f'{F_PATH}/{func.__name__}_hidden_interval_approx_{z_ang_hori}_{z_ang_vert}.png',
                                                       x_label='# hidden', y_label='# interval length',
                                                       z_label='L2 approximation error',
                                                       rotate_z=(z_ang_hori, z_ang_vert))
    print("Done")



    ##############################################
    # P5.3: Improving the approximation accuracy #
    ##############################################
    # <START Your code here>

    # <END Your code here>