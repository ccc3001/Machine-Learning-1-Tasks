Notes: 
Complex Fourier Series: https://www.youtube.com/watch?v=4cfctnaHyFM

# Programming Exercise 5: Approximation error of continual neural networks
In the lecture, you learned about the relation between the approximation error and the number of hidden units in continuous neural networks (Barron's theorem). Now you will validate the claims of the lecture empirically, building on the previous P4 exercise. You will also start learning how to use Pytorch for implementing and training neural networks. To this end, consider the  code in [approximation_error.py](approximation_error.py)

## P5.1 - Use Pytorch to train a network (3P). 
Look into the provided Pytorch implementation of the Continuous Neural Network `BetterPytorchContiNN` in [approx_err_util.py](approx_err_util.py). Create an instance of the network class with 255 hidden units and train it to approximate  <img src="https://latex.codecogs.com/svg.latex?f_1 = e^{-x^2/2}"> in the interval [-1.1]. 
As the hyperparameters for the `.fit` call of the approximator use the global variables you find in the code. 

According to Barron's Theorem, the number of required hidden units  to approximate <img src="https://latex.codecogs.com/svg.latex?e^{-x^2/2} "> up to an upper l2-bound of 0.1 is 255 for the interval [-1,1]. Can you confirm this? 

## P5.2 - Investigate the relation between approximation accuracy, interval and hidden units. Implement nested loops over the number of hidden units and the interval length, so that you can compute the approximation error for all three functions of P5.1. and for all combinations of hidden units and interval lengths.  

Use the following numbers of hidden units: 
1. 1
2. 5
3. 25
4. 50
5. 255
6. 400
7. 800
8. 1600
9. 3200
10. 6400

Use the following intervals: 
1. [-1, 1]
2. [-2, 2]
3. [-4, 4]
4. [-8, 8]

As a result, the code within the `.fit` function should plot 40 graphs per function for you, where the z-Axis displays the L2-Error, the x-Axis the number of hidden units and the y-Axis the interval length. Which number of hidden units gives the best results for each function-interval pair, i.e., where are the sweet spots? Is it always the highest number of neurons?


## P5.3 - Competition: Improve the Pytorch implementation (Best student gets 5P)
Try improving the pytorch implementation of the class `BetterPytorchContiNN` in [approx_err_util.py](approx_err_util.py), so that the approximation accuracy improves while maintaining the same number of parameters (weights and thresholds) as a single-layer network with 255 hidden units. 
Therefore, you should implement a new class `EvenBetterPytorchContiNN` that inherits from `BetterPytorchContiNN`. In this new class, you should overwrite the `__init__` and `forward` functions if necessary. 

The student with the lowest approximation error for the function  <img src="https://latex.codecogs.com/svg.latex?e^{-x^2/2} "> in [-1,1] gets the points for this exercise. You are also not allowed to change `N_EPOCHS` and `N_TRAIN_DATAPOINTS`. Other than that, you can try improving the network in any way you want, as long as you understand what you are doing. We suggest trying the following methods (without guarantee that they will indeed improve the results):

1. Add another layer of neurons to the Network. If you do this, keep in mind that this will significantly increase the total number of parameters of the network. That is, two hidden layers with 100 neurons each have many more weight parameters than one hidden layer with 200 neurons, at least for small input dimensions. Can you derive a formula to calculate how many parameters (weights and thresholds) there are in total for n-layer neural networks (2P)? Remember, there should not be more parameters than a network with a single hidden layer with 255 neurons would have. 
2. Use different activation functions (e.g. ReLu, tanh, etc.). This should be implemented in the `forward` function of your new Network class. 

