import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
import time
import random
from numpy.random import default_rng
from tqdm import tqdm
from collections import OrderedDict
from mcp import MCPNeuron, generate_boolean_functions, gen_lin_sep_dataset

from helper_functions import get_radius, gen_lin_sep_dataset, inner_prod
from plot_functions import init_2D_linear_separation_plot, update_2D_linear_separation_plot, plot_3d_surface

class MCPNetwork:
    def __init__(self, n_inputs, n_hidden, w=None, threshold=0):
        # Set weights of output neuron (not of hidden neurons)
        if w is None:
            self.w = np.zeros(n_hidden)
        else:
            assert len(self.w) == n_hidden, "Error, number of inputs must be the same as the number of hidden units."
            self.w = w
        # Set threshold of output neuron (not of hidden neurons)
        self.threshold = threshold

        # <START Your code here>
        # Add the hidden units
        # Create a list of hidden MCP units according to n_inputs and n_hidden.

        # <END Your code here>
        return

    def forward(self, x):
        """
        :param x: The input values
        :return: The output in the interval [-1,1]
        """
        y = 0 # TODO: overwrite this y.
        # <START Your code here>
        # <END Your code here>
        return y

    # Implement a function to randomize the weights and the threshold
    def set_random_params(self):
        # <START Your code here>

        # <END Your code here>
        return

    # Implement a function to check whether the MCP neuron represents a specific Boolean Function
    def is_bf(self, bf):
        fail = True
        # <START Your code here>

        # <END Your code here>
        return not fail


if __name__ == '__main__':
    # Implement an evaluation script to estimate how many Boolean functions can be approximated with a MCP network, in dependence on the number of hidden units.
    n_inputs_to_test = range(1,5)
    n_hidden_to_test = range(1,6)

    # TODO: Overwrite this succ_rates dictionary with the correct success rate values. This dictionary should contain, for each number of inputs and for each number of hidden units,
    #  the fraction of linear threshold functions, i.e., the number of Boolean functions that can be approximated
    #  with a MCP network.
    succ_rate = 0
    succ_rates = {n_inputs: {n_hidden: succ_rate for n_hidden in n_hidden_to_test} for n_inputs in n_inputs_to_test}
    max_samples_to_test = 100
    max_guesses = 2000

    # <START Your Code Here>

    # <END Your Code Here>

    # Plot the success rates as 3D surface plot.
    plot_3d_surface(succ_rates)




