import torch as th
import torch.nn as nn
import torch.nn.functional as F
import copy
import numpy as np
import torch.optim as optim
from tqdm import tqdm
from torch.autograd import Variable
from torch.utils.data import Dataset, DataLoader
from matplotlib import pyplot
from math import cos, sin, atan
import matplotlib.pyplot as plt
import os

class PrepareData(Dataset):

    def __init__(self, X, y):
        if not th.is_tensor(X):
            self.X = th.from_numpy(X)
        else:
            self.X = X

        if not th.is_tensor(y):
            self.y = th.from_numpy(y)
        else:
            self.y = y

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


def L2Loss(yhat,y):
    return th.sqrt(th.mean((yhat-y)**2))

class BetterPytorchContiNN(nn.Module):

    def __init__(self, n_inputs, n_hidden, lr=0.003, opti_str='sgd', batch_size=0, sampling='homogeneous'):
        super().__init__()
        self.n_inputs = n_inputs
        self.n_hidden = n_hidden
        self.__name__ = f"ContiNN_{opti_str}_{n_inputs}_{n_hidden}_{lr}_{sampling}_{batch_size}"
        self.hidden_layer = nn.Linear(n_inputs, n_hidden)
        self.output = nn.Linear(n_hidden, 1)
        if opti_str == 'adam':
            opti_class = optim.Adam
        elif opti_str == 'sgd':
            opti_class = optim.SGD
        else:
            opti_class = optim.SGD
            print(f"Warning, optimizer {opti_str} not known, using SGD")
        self.lr = lr
        self.optimizer = opti_class(self.parameters(), lr=lr)
        self.batch_size = batch_size
        self.sampling = sampling
        self.optimizer.zero_grad()
        self.loss_function = L2Loss
        self.count_parameters()
        return

    def forward(self, x):
        """
        :param x: The input values
        :return: The output
        """
        x = th.asarray(x, dtype=th.float32)
        hidden_activations = F.sigmoid(self.hidden_layer(x))
        output = self.output(hidden_activations)
        return output

    def count_parameters(self):
        params = list(self.parameters())
        n_params = 0
        for p in params:
            p_size = p.size().numel()
            # print(f"Parameters: {p}. ")
            # print(f"This parameter set contains {p_size} values")
            n_params += p_size
        print(f"Total number of parameters: {n_params}")
        return n_params

    def fit(self, func, n_epochs, x_start, x_end, n_train_datapoints, figure_path=None, figure_filename=None, best_err=None):
        if best_err is None:
            best_err = np.inf
        if self.batch_size == 0:
            batch_size = n_train_datapoints
        else:
            batch_size = self.batch_size
        assert n_train_datapoints % batch_size == 0, "Error, number of training data points must be divisible by batch size"

        if self.sampling == 'homogeneous':
            x_step = (x_end - x_start) / n_train_datapoints
            xs = th.arange(x_start, x_end, x_step, dtype=th.float32)
            xs = xs.reshape(xs.size()[0], 1)
        elif self.sampling == 'random':
            xs = th.rand((n_train_datapoints,1))
            xs *= x_end - x_start
            xs += x_start

        ys = th.asarray([func(x) for x in xs], dtype=th.float32)

        ds = PrepareData(xs, ys)
        ds = DataLoader(ds, batch_size=batch_size, shuffle=False)

        loss_hist = []
        last_epoch_ys_approx = []
        last_epoch_xs = []
        last_epoch_ys_orig = []
        loss_metric = np.inf
        for epoch in tqdm(range(n_epochs)):
            # Set the adaptive learning rate according to the number of epochs processed so far.
            this_lr = self.lr * (n_epochs - epoch) / n_epochs
            try:
                self.optimizer.param_groups[0]['lr'] = this_lr
            except:
                print("Error could not adapt learning rate to epoch number")

            # Iterate over batches
            for xs_batch, ys_batch in ds:
                xs_batch = Variable(xs_batch).float()
                ys_batch = Variable(ys_batch).float()
                ys_approximator = self(xs_batch)
                loss = self.loss_function(ys_approximator, ys_batch)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                loss_hist.append(loss.data.detach().numpy())
                if epoch == n_epochs - 1:

                    last_epoch_xs += list(xs_batch.detach().numpy().ravel())
                    last_epoch_ys_orig += list(ys_batch.detach().numpy().ravel())
                    last_epoch_ys_approx += list(ys_approximator.detach().numpy().ravel())
                    loss_metric = float(loss_hist[-1])

        if loss_metric < best_err:
            new_figure_filename = f"{loss_metric:.5f}_{figure_filename}"
            fig, ax = plt.subplots(figsize=(10, 10))
            plt.plot(last_epoch_xs, last_epoch_ys_approx, label="Approximator")
            plt.plot(last_epoch_xs, last_epoch_ys_orig, label="Original function")
            plt.legend()
            plt.title(f'{func.__name__} - {self.__name__} - err: {float(loss_hist[-1])}')
            if figure_path is not None and figure_filename is not None:
                plt.savefig(os.path.join(figure_path, new_figure_filename))
            else:
                plt.show()

            fig, ax = plt.subplots(figsize=(10, 10))
            plt.yscale("log")
            plt.plot(np.arange(len(loss_hist)), loss_hist, label="L2 Loss")
            plt.legend()
            plt.title(f'{func.__name__} - {self.__name__} - err: {int(loss_hist[-1])}')
            if figure_path is not None and figure_filename is not None:
                plt.savefig(os.path.join(figure_path, new_figure_filename[:-4]+"_loss.png"))
            else:
                plt.show()

        return loss_metric


class EvenBetterPytorchContiNN(BetterPytorchContiNN):
    def __init__(self, n_inputs, n_hidden, lr=0.02, opti_str='sgd', batch_size=0, sampling='homogeneous'):
        ##############################################
        # P5.3: Improving the approximation accuracy #
        ##############################################
        nn.Module.__init__(self)
        # <START Your code here>
        self.n_inputs = n_inputs
        self.n_hidden = n_hidden
        self.__name__ = f"ContiNN_{opti_str}_{n_inputs}_{n_hidden}_{lr}_{sampling}_{batch_size}"
        self.hidden_layer_1 = nn.Linear(n_inputs, n_hidden)
        self.hidden_layer_2 = nn.Linear(n_hidden, n_hidden)
        self.output = nn.Linear(n_hidden, 1)
        if opti_str == 'adam':
            opti_class = optim.Adam
        elif opti_str == 'sgd':
            opti_class = optim.SGD
        else:
            opti_class = optim.SGD
            print(f"Warning, optimizer {opti_str} not known, using SGD")
        self.lr = lr
        self.optimizer = opti_class(self.parameters(), lr=lr)
        self.batch_size = batch_size
        self.sampling = sampling
        self.optimizer.zero_grad()
        self.loss_function = L2Loss
        self.count_parameters()
        return

    def forward(self, x):
        # <REMOVE the following to run your own __init__ code>
        # output = super().forward(x)
        # <START Your code here>
        x = th.asarray(x, dtype=th.float32)
        hidden_1_activations = F.relu(self.hidden_layer_1(x))
        hidden_2_activations = F.relu(self.hidden_layer_2(hidden_1_activations))
        output = self.output(hidden_2_activations)
        # <END Your code here>
        return output