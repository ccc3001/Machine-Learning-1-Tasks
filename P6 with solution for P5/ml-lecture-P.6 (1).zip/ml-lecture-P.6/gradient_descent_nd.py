import numpy as np
from sklearn import datasets
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import seaborn as sns


import time
def gen_dataset(n_samples=4, noise=0, dim=3):
    x, y = datasets.make_regression(n_samples=n_samples, n_features=dim, n_informative=n_samples//10+1, noise=noise)
    y = y - min(y)
    y = y / max(y)
    return (x,y)


def compute_loss(x,y,w,b):
    n_data = len(x)
    predictions = sigmoid(np.inner(w, x) + b)
    squared_errors = (y - predictions) ** 2
    l = np.sum(squared_errors) / n_data
    return l


def sigmoid(x):
    return 1 / (1+np.exp(-x))


def sigmoid_derivative(x):
    return sigmoid(x) * (1 - sigmoid(x))



def fit_once(x, y, w, b, learning_rate=1):
    """
    Fits the parameters w and b to the data points x and y
    :param x: The perceptron inputs
    :param y: The ground-truth of the prediction
    :param w: The weight of the perceptron
    :param b: The bias of the perceptron
    :return: b_new, w_new, loss_before, loss_after: The updated parameters and the loss before and after the parameter update
    """
    n_data = len(x)
    # pr = np.inner(x, w)
    # The update rule according to Sec. 3.7, Case 1.
    pred = sigmoid(np.inner(w,x) + b)
    diff = (y - pred)

    dsig = -sigmoid_derivative(np.inner(w,x) + b)
    dsigx = np.multiply(dsig, x.T)

    dw = diff * dsigx
    dw_mean = np.mean(dw, axis=1)

    db = diff * -sigmoid_derivative(np.inner(w,x) + b)
    db_mean = np.mean(db, axis=0)
    # db_mean = 0
    w = w - learning_rate * dw_mean
    b = b - learning_rate * db_mean
    print(f"New w: {w}, new b: {b}.")
    return w, b


if __name__ == "__main__":
    fail = False
    n_samples = 3
    epsilon = 1
    n_inputs = 1
    print(f"N samples: {n_samples} \t lr: {epsilon}")
    initial_loss = 0
    x, y = gen_dataset(n_samples=n_samples, noise=9, dim=n_inputs)
    x = np.array([[0.0], [0.5], [1.0]])
    y = np.array([1.0, 0., 1.])
    w = np.zeros(n_inputs)
    b = 0
    convergence_threshold = 0.01
    n_upd = 0
    loss = compute_loss(x, y, w, b)
    while True:
        loss_before = loss
        w, b = fit_once(x, y, w, b, learning_rate=epsilon)
        loss = compute_loss(x, y, w, b)
        print(f"This fitting epoch reduced the loss from {loss_before} to {loss}")
        if initial_loss == 0:
            initial_loss = loss_before
        if loss < convergence_threshold:
            print(f"Convergence for epsilon {convergence_threshold} achieved after {n_upd} updates. Loss is now {loss} and I am happy.")
            # print("Press enter to quit.")
            break
        if loss > loss_before:
            print("This should not happen...")
            fail = True
            # break
        n_upd += 1

